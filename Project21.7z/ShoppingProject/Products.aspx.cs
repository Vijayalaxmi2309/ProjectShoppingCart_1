﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ShoppingProject
{
    public partial class Products : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            

            if (Request.QueryString["cat"] != null)

            {
                DataList1.DataSourceID = null;
                DataList1.DataSource = sqldatasource2;
                DataList1.DataBind();
            }


        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
    
        }

        protected void ImageButton1_Command(object sender, CommandEventArgs e)
        {

        }

        protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "addtocart")
            {

                DropDownList dlist = (DropDownList)(e.Item.FindControl("DropDownList1"));
                Response.Redirect("AddtoCart.aspx?id=" + e.CommandArgument.ToString() + "&quantity=" + dlist.SelectedItem.ToString());

            }
        }
        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Products.aspx?cat=Electronics");

        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Products.aspx?cat=Accessories");
        }

        protected void LinkButton3_Click(object sender, EventArgs e)
        {
            Response.Redirect("Products.aspx?cat=Grocery");
        }

        protected void LinkButton4_Click(object sender, EventArgs e)
        {
            Response.Redirect("Products.aspx?cat=Clothing");
        }

        protected void LinkButton5_Click(object sender, EventArgs e)
        {
            Response.Redirect("Products.aspx");
        }

        protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}