﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ShoppingProject
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        string _myConnectionString = @"data source = ndamssql\sqlilearn; user id = sqluser; password = sqluser; initial catalog = training_19sep18_pune;";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            SqlCommand cmd = new SqlCommand();
            cmd = new SqlCommand();
            SqlConnection con = new SqlConnection(_myConnectionString);
            cmd.CommandText = "ForgotPassword_SSVPP";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();

            cmd.Parameters.AddWithValue("@Name", txtname.Text);
            cmd.Parameters.AddWithValue("@Password1", txtPassword1.Text);
            cmd.Parameters.AddWithValue("@securityqtn", DropDownSecurity.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@answer", txtAnser1.Text);
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            cmd.ExecuteNonQuery();
            lbl123.Text = "Your Password has been changed";


        }
        

       
    

    protected void Button2_Click(object sender, EventArgs e)
        {
           
           Response.Redirect("LogIn.aspx");
        }
    }
}